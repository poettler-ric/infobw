#!/usr/bin/env python


"""Functions don't need to take arguments."""


from sys import argv


def no_args():
    """Function taking no arguments."""
    print("no args")


def main():
    """Main function."""
    print(argv[0])
    print(argv)
    print(5 % 2)
    print(5 / 2)


if __name__ == '__main__':
    no_args()
    main()

    matrix = [
        [1, 2],
        [3, 4]
    ]
    row = 0
    column = 1
    print(matrix[row][column])
