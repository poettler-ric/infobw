#!/usr/bin/env python


"""Dictionary example code."""


from sys import argv


def myunique_list(l):
    """Returns a list of unique values"""
    result = []
    for i in l:
        if not i in result:
            result.append(i)
    return result


def myunique_dict(l):
    """Returns a list of unique values using a dictionary"""
    result = {}
    for i in l:
        result[i] = 0
    return result.keys()


if __name__ == '__main__':
    words = {'hallo': 'hello', 'hund': 'dog'}
    print(words)
    print(words['hund'])

    # everything can be a key
    numbers = {0.1: "asdf", 0.2: "asdfasdf"}
    print(numbers[0.1])

    numbers[0.1] = "hello"
    print(numbers[0.1])

    print("= listing values")
    for value in words.values():
        print(value)

    print("= listing keys")
    for key in numbers.keys():
        print(key)

    print("= iterating over a dictionary")
    for key, value in words.items():
        print("{} => {}".format(key, value))

    # example usage storing horsepower of cars
    horsepower = {
        'Porsche': 400,
        'VW': 300,
        'Audi': 200,
    }

    if not argv[1] in horsepower:
        print("no mapping yet")
        new_mapping = raw_input("enter value: ")
        horsepower[argv[1]] = int(new_mapping)
        print(horsepower)

    print(horsepower[argv[1]])

    # dicts  can be used to store user data
    users = {
        'peter': 'geheim',
        'hans': 'asdf',
        'gabi': 'jkl',
    }

    user = raw_input("please enter a unsername: ")
    password = raw_input("please enter a password: ")
    if user not in users:
        print("unknown user")
    elif users[user] == password:
        print("access")
    else:
        print("no access")

    # .get can be used to avoid exceptions when a key is not stored, yet
    print("password = {}".format(users.get(user, "not stored")))

    print(myunique_list([5, 5, 6, 7, 8, 8]))
    print(sorted(myunique_dict([5, 5, 6, 7, 8, 8])))
