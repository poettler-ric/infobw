#!/usr/bin/env python


"""Matplotlib examplecode"""


from matplotlib.pyplot import grid, legend, plot, savefig, show, title, xlabel, ylabel

if __name__ == '__main__':
    income1 = [5, 6, 5, 6, 6, 7, 5, 9, 5, 1, 3, 6]
    income2 = []
    for i in income1:
        income2.append(i * 2)

    months = range(1, 13)

    plot(months, income1, label="Person 1")
    plot(months, income2, label="Person 2")
    grid(True)
    legend()
    title("Verdienste")
    xlabel("Monate")
    ylabel("Einkommen")
    savefig("einkommen.png")
    show()
