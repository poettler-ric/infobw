#!/usr/bin/env python


"""Converts to and from roman numbers."""


def roman_decimal_if(roman):
    """Converts roman numbers to decimal."""
    result = 0
    for c in roman:
        if c == 'I':
            result += 1
        elif c == 'V':
            result += 5
        elif c == 'X':
            result += 10
        elif c == 'L':
            result += 50
        elif c == 'C':
            result += 100
        elif c == 'D':
            result += 500
        elif c == 'M':
            result += 1000
        else:
            raise ValueError("unsupported character: {}".format(c))
    return result


def roman_decimal_dict(roman):
    """Converts roman numbers to decimal using a dictionary."""
    result = 0
    translation = {
        'I': 1,
        'V': 5,
        'X': 10,
        'L': 50,
        'C': 100,
        'D': 500,
        'M': 1000
    }

    for i in roman:
        result += translation[i]
    return result


def decimal_roman_iterating(decimal):
    """Converts decimal to roman numbers."""
    remaining = decimal
    result = ""
    result += "M" * (remaining / 1000)
    remaining %= 1000
    result += "D" * (remaining / 500)
    remaining %= 500
    result += "C" * (remaining / 100)
    remaining %= 100
    result += "L" * (remaining / 50)
    remaining %= 50
    result += "X" * (remaining / 10)
    remaining %= 10
    result += "V" * (remaining / 5)
    remaining %= 5
    result += "I" * (remaining / 1)
    remaining %= 1
    return result


def decimal_roman_loop(decimal):
    """Converts decimal to roman numbers."""
    divisors = (1000, 500, 100, 50, 10, 5 , 1)
    roman = "MDCLXVI"
    remaining = decimal
    result = ""
    for i in range(len(divisors)):
        result += roman[i] * (remaining / divisors[i])
        remaining %= divisors[i]
    return result


decimal_roman = decimal_roman_loop
roman_decimal = roman_decimal_dict

if __name__ == '__main__':
    initial = 7777
    calculated_roman = decimal_roman(initial)
    calculated_back = roman_decimal(calculated_roman)
    print("decimal: {} roman: {} matches: {}".format(initial,
                                                     calculated_roman,
                                                     initial == calculated_back))
