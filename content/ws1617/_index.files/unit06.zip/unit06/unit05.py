#!/usr/bin/python

MENU  = """Please choose an option:
1) first option
2) second option
choice: """

def read_int(prompt):
    """Reads an interger from stdin."""
    s = raw_input(prompt)
    return int(s)

def main():
    """Main function/entry point for the program."""
    option = read_int(MENU)
    while option != 1 and option != 2:
        print("Falsche Eingabe")
        option = read_int(MENU)
    print(option)

if __name__ == '__main__':
    main()
