#!/usr/bin/python

"""Example list usage."""

def main():
    """Main function/entry point for the program."""

    #        0        1        2
    names = ["Anton", "Berta", "Caesar"]
    print(names)

    # accessing certain elements
    print(names[1])

    # appending elements to the end of the list
    names.append("Delta")
    #         0        1        2         3
    #names = ["Anton", "Berta", "Caesar", "Delta"]
    print(names)

    # deleting certain elements
    del names[2]
    #         0        1        2
    #names = ["Anton", "Berta", "Delta"]
    print(names)

    # length of a list
    print(len(names))

    # searching within a list
    pos = names.index("Berta")
    print(pos)

    # iterating through a list
    i = 0
    while i < len(names):
        element = names[i]
        print(element)
        i += 1

    # shorter version
    for i in range(len(names)):
        element = names[i]
        print(element)

    # shortest version to iterate through a list
    for element in names:
        print(element)

    # assign a value to a given element in a list
    names[1] = "Hugo"
    #         0        1       2
    #names = ["Anton", "Hugo", "Delta"]
    print(names)


if __name__ == '__main__':
    main()
