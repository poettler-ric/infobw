#!/usr/bin/python

"""
Collection of functions interacting with lists.
"""

def my_sum(l):
    """Sums up elements in a list."""
    result = 0
    for i in l:
        result += i


def average(l):
    """Calculates the average of a list of items."""
    result = 0
    for i in l:
        result += i
    result = result / float(len(l))
    return result


def my_min(l):
    """Determines the smallest element in a list.

    my_min because we don't want to overwrite the default min function"""
    smallest = None
    for i in l:
        if i < smallest or smallest == None:
            smallest = i
    return smallest


def my_max(l):
    """Determines the greatest element in a list.

    my_max because we don't want to overwrite the default max function"""
    greatest = None
    for i in l:
        if i > greatest or greatest == None:
            greatest = i
    return greatest


def intersect(l1, l2):
    """Determines the intersection of two lists."""
    result = []
    for i in l1:
        if i in l2:
            result.append(i)
    return result


def main():
    """Main function/entry point for the program."""
    elements = [1, 2, 3, 4]
    second_list = [3, 4, 5, 6]
    print(my_sum(elements))
    print(average(elements))
    print(my_min(elements))
    print(intersect(elements, second_list))

if __name__ == '__main__':
    main()
