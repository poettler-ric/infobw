#!/usr/bin/python

"""Vectors can be handled with lists."""

def mulitply_vector(v, factor):
    """Multipies a vector with a scalar."""
    result = []
    for i in v:
        result.append(i * factor)
    return result


def add_vectors(v1, v2):
    """Adds two vectors"""
    if len(v1) != len(v2):
        exit('length of vectors must match.')

    result = []
    i = 0
    while i < len(v1):
        result.append(v1[i] + v2[i])
        i += 1
    return result


def print_vector(v):
    """Prints a vector to stdout."""
    print('===')
    for i in v:
        print(i)
    print('===')

def main():
    """Main function/entry point for the program."""
    # vector:
    # 5
    # 6
    #          x  y
    vector1 = [5, 6]
    print_vector(vector1)

    multiplied = mulitply_vector(vector1, 5)
    print_vector(multiplied)

    vector2 = [1, 1]
    added = add_vectors(vector1, vector2)
    print_vector(added)


if __name__ == '__main__':
    main()
