#!/usr/bin/python


"""a string is a lists of characters."""

def main():
    """Main function/entry point for the program."""
#           012345
    test = "Sums up elements in a list."
    print(test[5])


if __name__ == '__main__':
    main()
