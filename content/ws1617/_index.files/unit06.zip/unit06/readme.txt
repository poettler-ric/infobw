Rubber duck debugging:
https://en.wikipedia.org/wiki/Rubber_duck_debugging

Formatting strings:
https://pyformat.info/

List documentation:
https://docs.python.org/2/library/stdtypes.html#sequence-types-str-unicode-list-tuple-bytearray-buffer-xrange

range function:
https://docs.python.org/2/library/functions.html#range