#!/usr/bin/env python

"""Assistance for assignment2."""

from sys import argv


def x_circle(x, y, r):
    """Placeholder for a function calculating stuff for a circle."""
    return 1 # placehoder for a returned value


def main():
    """Main function running the program."""
    i = 1
    #  0                 1    2    3    4    5    6    7
    # ['assignment2.py', '+', 'r', 'x', 'y', 'a', 'b', '-', 'c', 'x', 'y', 'r']
    #                    i    i+1  i+2  i+3
    # i += ...
    #                                                  i    i+1  i+2  i+3
    print(argv)
    while i < len(argv):
        # get common parameters
        shape = argv[i+1]
        x = 0 # get and convert x
        y = 0 # get and convert y
        i += 4
        if shape == '':
            i += 2
        elif shape == 'c':
            x_circle(x, y, float(argv[i]))
            i += 1


if __name__ == '__main__':
    main()
