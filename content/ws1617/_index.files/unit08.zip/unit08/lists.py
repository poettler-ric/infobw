#!/usr/bin/env python

"""Some simple list functions."""

from sys import argv


def sort(args):
    """Sort implementation.

    Uses the bubble sort algorithm.
    Usually the builtin function sorted(...) should be used."""
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(args) - 1:
            if args[i] > args[i+1]:
                args[i], args[i+1] = args[i+1], args[i]
                changed = True
            i += 1
    return args


def reversing_list(args):
    """Reverses a list.

    Usually the builtin function reversed(...) should be used.
    """
    result = []
    # len("asdfg") = 5
    #  01234
    # "asdfg"
    # index of 'g' = len("asdfg") - 1 - 0
    # index of 'f' = len("asdfg") - 1 - 1
    # index of 'd' = len("asdfg") - 1 - 2
    # ...
    for i in range(len(args)):
        result.append(args[len(args) - 1 - i])
    return result


def reversing_slice(args):
    """Shorter version of reverse using slice syntax."""
    return args[::-1]

# functions are ordinary values an can be assigned to variables or stored in lists.
reversing = reversing_list


def main():
    """Main function running the program."""
    numbers = []
    for a in argv[1:]:
        numbers.append(int(a))
    r = reversing(numbers)
    print(r)
    print(sort(r))


if __name__ == '__main__':
    main()
