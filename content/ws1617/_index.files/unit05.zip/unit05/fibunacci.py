#!/usr/bin/python

"""Testing a function to calculate fibunacci numbers"""

def fibunacci(maximum):
    """Calculates fibunacci numbers up to a given maximum"""
    
    a, b, c = 0, 1, 0
    print(a)
    print(b)
    while c <= maximum:
        print(c)
        c = a + b
        a = b
        b = c


if __name__ == '__main__':
    fibunacci(611)
