
#!/usr/bin/python

"""Calculates the greates common divisor"""

def read_int(prompt):
    """Reads an integer from stdin."""

    text = raw_input(prompt)
    number = int(text)
    return number


if __name__ == '__main__':
    number1 = read_int("please enter number 1: ")
    number2 = read_int("please enter number 2: ")

    guess = min(number1, number2)
    bigger = max(number1, number2)

    loop = True
    while loop:
        if number1 % guess == 0 and number2 % guess == 0:
            print("the gcd of %d and %d is %d" % (number1, number2, guess))
            loop = False
        guess -= 1
