#!/usr/bin/python

"""Shows the general definition and usage of a function."""

def func_name(arg1, arg2):
    return arg1 + arg2

if __name__ == '__main__':
    func_name(1, 2)
