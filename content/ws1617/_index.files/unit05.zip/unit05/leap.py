#!/usr/bin/python

"""
Berechnung von Schaltjahren:

Algorithmus:
https://en.wikipedia.org/wiki/Leap_year#Algorithm

Vorgehensweise:
- Zahl in Variable -> ueberpruefung ob Schaltjahr
- Zahl einlesen / Menue?
- Ueberpruefung in Funktion
- Berechnung der naechsten x Schaltjahre

Anmerkung:
x not divisible by z -> y % x != 0
"""

def read_int(prompt):
    """Reads from stdin and converts it to an integer."""

    text = raw_input(prompt)
    return int(text)


def is_leap_year(year):
    """Checks whether a given year is a leap year."""

    is_leap = False

    if (year % 4 != 0):
        is_leap = False
    elif (year % 100 != 0):
        is_leap = True
    elif (year % 400 != 0):
        is_leap= False
    else:
        is_leap = True

    return is_leap


if __name__ == '__main__':
    calculated = 0
    current_year = read_int("Please enter a starting year: ")
    max_calc = read_int("Please enter a number of leap years to calculate: ")

    while calculated < max_calc:
        if is_leap_year(current_year):
            print("is leap: %d" % current_year)
            calculated += 1
        current_year += 1
