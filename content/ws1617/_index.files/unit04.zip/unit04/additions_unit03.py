#!/usr/bin/python

"""Additional information to unit 03.

This string is called a module documententation and summarizes the program
"""

LONG_STRING = """first line
second line
third line"""

# This is called a main guard clause and marks the executeable part of  a
# script.
# Having such a clause is considered good programming practice.
# __main__  is a variable defined by the python interpreter itself.
if __name__ == '__main__':
    # break/continue to control a loop
    i = 0
    while i < 10:
        i += 1
        if i == 4:
            print("don't need 4")
            continue
        if i == 8:
            print("enough counting at 8")
            break
        print("counting %d" % i)


    # printing multiple lines
    # possibility 1: explicit linebreaks in string
    print("first line\nsecond line\nthird line")

    # possibility 2: separate print statements
    print("first line")
    print("second line")
    print("third line")

    # possibility 4: define a long string and print at once
    print("""first line
second line
third line""")

    # possibility 4: define a long string and print at once
    print(LONG_STRING)
