#!/usr/bin/python

"""Calculate the greatest common divisor of two numbers."""

if __name__ == '__main__':
    text = raw_input("please enter the first number: ")
    number1 = int(text)
    text = raw_input("please enter the second number: ")
    number2 = int(text)

    # TODO: check if both numbers are positive

    guess = min(number1, number2)
    # test all numbers down from the smaller one whether both numbers are
    # dividable by it
    while guess > 1 and (number1 % guess != 0 or number2 % guess != 0):
        guess -= 1
    print("the gcd of %d and %d is %d" % (number1, number2, guess))
