#!/usr/bin/python

"""Checks whether a given number is a prime."""

if __name__ == '__main__':
    number = -1

    while number != 0:
        text = raw_input("please enter a positive number (0 to exit): ")
        number = int(text)

        if number == 0:
            print("exiting...")
        elif number < 0:
            print("we need a positive number!")
        elif number == 1:
            print("%d is not a prime" % number)
        else:
            testing = 2
            is_prime = True
            # test all possible numbers
            while testing < number and is_prime:
                # whether our current one is dividable
                if number % testing == 0:
                    is_prime = False
                testing += 1
            if is_prime:
                print("%d is a prime" % number)
            else:
                print("%d is not a prime" % number)
