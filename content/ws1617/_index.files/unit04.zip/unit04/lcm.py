#!/usr/bin/python

"""Calculate the least commom multiple of two numbers."""

if __name__ == '__main__':
    text = raw_input("please enter the first number: ")
    number1 = int(text)
    text = raw_input("please enter the second number: ")
    number2 = int(text)

    # TODO: check if both numbers are positive

    bigger = max(number1, number2)
    smaller = min(number1, number2)

    i = 1
    # test whether a multiple of the bigger number is dividable by the smaller
    # one
    while (bigger * i) % smaller != 0:
        i += 1
    print("the lcm of %d and %d is %d" % (number1, number2, bigger * i))
