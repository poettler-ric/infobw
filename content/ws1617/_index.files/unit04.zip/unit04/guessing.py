#!/usr/bin/python

"""A simple number guessing game."""

import random

if __name__ == '__main__':
    text = raw_input("please enter a maximum number: ")
    maximum = int(text)

    if maximum <= 0:
        exit('must be a number greater than 0')
    generator = random.SystemRandom()
    number = generator.randint(1, maximum)

    guessing = True
    while guessing:
        text = raw_input("geuss a number: ")
        guess = int(text)

        if guess < number:
            print("too small")
        elif guess > number:
            print("too big")
        else:
            print("you got the right number")
            guessing = False
