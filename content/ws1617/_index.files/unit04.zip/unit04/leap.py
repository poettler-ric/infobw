#!/usr/bin/python

"""Calculate the next x leap years.

The algorithm is taken from https://en.wikipedia.org/wiki/Leap_year#Algorithm
"""

import datetime

YEARS_TO_CALCULATE = 30

if __name__ == '__main__':
    calculated_years = 0
    now = datetime.datetime.now()
    year = now.year
    while calculated_years < YEARS_TO_CALCULATE:
        # every 4th, but not every 100th year is a leap year
        # but every 400th is one, too
        if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
            print(year)
            calculated_years += 1
        year += 1
