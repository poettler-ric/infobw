# input 2 numbers
text = raw_input("enter number1: ")
number1 = int(text)

text = raw_input("enter number2: ")
number2 = int(text)

# input operator (+ - * /)
operator = raw_input("enter an operator [+-*/]: ")

# calc
if operator == "+":
	result = number1 + number2
elif operator == "-":
	result = number1 - number2
elif operator == "*":
	result = number1 * number2
elif operator == "/":
	result = number1 / number2

# output
print("%s %s %s = %s" % (number1, operator, number2, result))

