# 0! = 1
# 1! = 1
# 2! = 1 * 2
# 3! = 1 * 3 * 2
# 5! = 1 * 5 * 4 * 3 * 2

# input
text = raw_input("enter a number: ")
number = int(text)

result = 1

# computation
if number == 0:
	result = 1
elif number == 1:
	result = 1
else:
	while number > 1:
		result = result * number
		number = number - 1
	
# output
print("result of %s! = %s" % (number, result))

