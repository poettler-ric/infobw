# input numbers
text = raw_input("please enter height [m]: ")
height = int(text)

text = raw_input("please enter width [m]: ")
width = int(text)

text = raw_input("please enter depth [m]: ")
depth = int(text)

print("computing with height=%s width=%s depth=%s" % (height, width, depth))

volume = height * width * depth
print("volume = %s [m3]" % volume)

DENSITY_STEEL = 7800 # kg/m3

mass = volume * DENSITY_STEEL
print("mass = %s [kg]" % mass)

GRAVITY = 9.81 # m/s^2

force = mass * GRAVITY
print("force = %s [N]" % force)
