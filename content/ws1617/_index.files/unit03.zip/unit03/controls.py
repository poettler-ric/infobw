num_seats = 50
num_students = 30

if num_seats > num_students:
	print("everything ok")
	print("everything ok")
elif num_seats == num_students: # else if
	print("perfect fit")
	print("perfect fit")
else:
	print("get a bigger room")
	print("additional statement")
print("done")

a = 5
while a > 0:
	print("counting down %s" % a)
	
	if a == 4:
		print("a is 4")
	
	a = a - 1

print("done")
