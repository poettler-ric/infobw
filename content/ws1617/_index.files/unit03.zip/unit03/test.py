print("test")

a = 42
b = 1.2
c = "test"
d = False
e = "42"

text = "a = %s, b = %s" % (a, b)
print(text)
print("b = %s" % b)
print("c = %s" % c)
print("d = %s" % d)

# here come a view computations
result = a * b
result = a - b
result = a / b
result = (a + b) * b

result = 13 / 5.0 
print("result 1 = %s" % result)
result = 13 % 5 
print("result 2 = %s" % result)

print("testing: %s" % (a == 5))
print("testing: %s" % (a != 5))
print("testing: %s" % (a > 5))
print("testing: %s" % (a < 5))
print("testing: %s" % (a >= 5))
print("testing: %s" % (a <= 5))

# float()
# int()
# str()

print("(e == str(a)) = %s" % (e == str(a)))
