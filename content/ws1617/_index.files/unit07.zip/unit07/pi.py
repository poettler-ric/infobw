#!/usr/bin/python

"""
Example code to access math.pi.
"""

if __name__ == '__main__':

    # first option
    import math
    print(math.pi)

    # second option
    from math import pi, sin, cos
    print(pi)

    print("{:.5f}".format(sin(pi)))
    print("{:.5f}".format(cos(pi)))
