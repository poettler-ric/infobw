#!/usr/bin/python

"""
Example code to append calculated values to a list.
"""

def xs_rect(x, a): # pylint: disable=C0103
    """"Calculates xs for a rectangle"""
    return x + a/2

if __name__ == '__main__':
    # pylint: disable=C0103
    xs = []
    print(xs)
    xs.append(xs_rect(0., 1.))
    print(xs)
    # pylint: enable=C0103
