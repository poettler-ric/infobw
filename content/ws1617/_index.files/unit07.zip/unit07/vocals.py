#!/usr/bin/python

"""
Count vocals in words given on the command line

Output:
counts in <word>: a=0 e=0 i=0 o=0 u=0
"""

from sys import argv

TEMPLATE = "counts in {}: a={} e={} i={} o={} u={}"

def count_char(word, to_count):
    """Returns the occurences of a given character in a word."""
    count = 0
    for char in word:
        if char == to_count:
            count += 1
    return count

if __name__ == '__main__':
    for argument in argv[1:]:
        print(TEMPLATE.format(argument,
                              count_char(argument, "a"),
                              count_char(argument, "e"),
                              count_char(argument, "i"),
                              count_char(argument, "o"),
                              count_char(argument, "u")))
