#!/usr/bin/python

"""
Checks whether word from command line are pallindromes.
"""

from sys import argv

def check_pallindrome(word):
    """
    Checks whether a word is a pallindrome.

    A Pallindrom is a word equal to the reversed version.

    len("hello") = 5
    len("hello")/2 = 2

    v   v
    01234
    hallo

     v v
    01234
    hallo

      v
    01234
    hallo
    """
    i = 0
    while i < len(word)/2:
        if word[i] != word[len(word) - 1 - i]:
            return False
        i += 1
    return True

if __name__ == '__main__':
    for a in argv[1:]:
        print("{} is a pallindrome: {}".format(a, check_pallindrome(a)))
