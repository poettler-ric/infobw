#!/usr/bin/python

"""
Stuff from previous lession.
"""

def calc(a, b): # pylint: disable=C0103
    """Some random calculation."""
    return a + b

def group_calc(a, b, c): # pylint: disable=C0103
    """Returns a list of calculated values."""
    return [a+b, b+c]

if __name__ == '__main__':
    # pylint: disable=C0103
    i = 1
    j = 2
    print(calc(i, j))

    #         0  1  2
    mylist = [1, 2, 3]
    print(mylist[1]) # 2
    mylist[2] = 4
    mylist.append(7)
    print(mylist)

    print(group_calc(1, 2, 3))

    #       01234
    word = "hello"
    print(word[2])
    #word[0] = "W" # => compile error!

    # iterate over characters:
    for char in word:
        print(char)
    # pylint: enable=C0103
