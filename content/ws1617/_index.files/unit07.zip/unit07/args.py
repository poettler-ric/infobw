#!/usr/bin/python

"""
argv indices:
0               1       2
<program name> <word1> <word2>

e.g.: python args.py + rect 0 0 1 2

argument at index 0: args
argument at index 1: +
argument at index 2: rect
argument at index 3: 0
argument at index 4: 0
argument at index 5: 1
argument at index 6: 2
"""

from sys import argv

if __name__ == '__main__':
    i = 0
    for a in argv:
        print("argument at index {}: {}".format(i, a))
        i += 1

    print('===')

    # list from    1 to 7
    for a in range(1, len(argv)):
        print(argv[a])
