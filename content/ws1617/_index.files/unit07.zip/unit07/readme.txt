Da ich das Gefuehl habe, dass sich ein paar bei den Programmierkonstrukten
schwer tun (unter Umstaenden liegt es an meinen Erklaerungkuensten) habe ich
euch von der offiziellen Seite mal die Dokumentation aus dem Tutorial rausgesucht.

Hier der Link zum Tutorial:
https://docs.python.org/2/tutorial/index.html

Tutorial zu if, for, range, pass, if/else, break and continue:
https://docs.python.org/2/tutorial/controlflow.html

Strings (Indexes koennen auch negativ sein (aber man kommt auch ohne diesen
Trick aus)):
https://docs.python.org/2/tutorial/introduction.html#strings

Listen generell:
https://docs.python.org/2/tutorial/introduction.html#lists

Weitere Dokumentation fuer Listen:
https://docs.python.org/2/tutorial/datastructures.html#more-on-lists
https://docs.python.org/2/library/stdtypes.html#sequence-types-str-unicode-list-tuple-bytearray-buffer-xrange

Funktionsdefinitionen (Hier wird auch das """, das ich immer verwende erklaert):
https://docs.python.org/2/tutorial/controlflow.html#defining-functions

Ich hoffe das hilft euch ein bisschen weiter.
